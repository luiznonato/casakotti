(function () {
	'use strict';
}());
